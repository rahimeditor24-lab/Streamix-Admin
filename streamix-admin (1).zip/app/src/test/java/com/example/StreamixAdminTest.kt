package com.example

import com.example.data.AdminAuthRepository
import com.example.data.AdminRepository
import com.example.model.SubscriptionTier
import com.example.model.UserStatus
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class StreamixAdminTest {

    private lateinit var authRepository: AdminAuthRepository
    private lateinit var adminRepository: AdminRepository

    @Before
    fun setUp() {
        authRepository = AdminAuthRepository()
        adminRepository = AdminRepository()
    }

    @Test
    fun testAdminLogin_validCredentials_succeeds() {
        val result = authRepository.login("lead_admin", "secureStreamix99#")
        assertTrue(result)
        assertNotNull(authRepository.currentAdmin.value)
        assertEquals("Lead_admin", authRepository.currentAdmin.value?.username)
    }

    @Test
    fun testAdminLogin_trivialCredentials_rejected() {
        val result = authRepository.login("admin", "admin")
        assertFalse(result)
        assertNull(authRepository.currentAdmin.value)
        assertNotNull(authRepository.loginError.value)
    }

    @Test
    fun testAdminRepository_initialTelemetry_isHealthy() {
        val telemetry = adminRepository.telemetry.value
        assertEquals("HEALTHY", telemetry.serverStatus)
        assertTrue(telemetry.totalUsers > 0)
    }

    @Test
    fun testAdminRepository_userStatusUpdate() {
        val users = adminRepository.users.value
        assertTrue(users.isNotEmpty())
        val firstUser = users.first()

        adminRepository.updateUserStatus(firstUser.id, UserStatus.SUSPENDED, "Terms violation")
        val updatedUser = adminRepository.users.value.find { it.id == firstUser.id }
        assertEquals(UserStatus.SUSPENDED, updatedUser?.status)
        assertEquals("Terms violation", updatedUser?.banReason)
    }

    @Test
    fun testAdminRepository_promoCodeCreation() {
        val initialCount = adminRepository.promoCodes.value.size
        adminRepository.createPromoCode(
            code = "STREAM50",
            discountPercent = 50,
            validUntil = "Dec 31, 2026",
            tier = SubscriptionTier.ULTRA_4K,
            maxRedemptions = 500
        )
        val updatedCodes = adminRepository.promoCodes.value
        assertEquals(initialCount + 1, updatedCodes.size)
        assertTrue(updatedCodes.any { it.code == "STREAM50" })
    }
}
