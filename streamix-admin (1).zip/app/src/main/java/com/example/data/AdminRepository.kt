package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AdminRepository {

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())

    // --- System Telemetry ---
    private val _telemetry = MutableStateFlow(
        SystemTelemetry(
            activeStreamers = 1420,
            totalUsers = 48920,
            pendingRequests = 8,
            activeAnnouncements = 3,
            monthlyRecurringRevenue = 84250.00,
            serverUptimePercent = 99.98,
            bandwidthUsageTb = 142.6,
            transcodingQueueJobs = 4,
            apiLatencyMs = 28,
            cpuUsagePercent = 42,
            ramUsagePercent = 67,
            cdnCacheHitRatePercent = 94.8,
            serverStatus = "HEALTHY"
        )
    )
    val telemetry: StateFlow<SystemTelemetry> = _telemetry.asStateFlow()

    // --- Users ---
    private val _users = MutableStateFlow<List<StreamixUser>>(listOf(
        StreamixUser(
            id = "USR-88219",
            username = "alex_vortex",
            email = "alex.vortex@example.com",
            tier = SubscriptionTier.ULTRA_4K,
            status = UserStatus.ACTIVE,
            joinedDate = "Jan 12, 2026",
            streamHours = 348.5,
            ipCountry = "United States",
            devicesCount = 4,
            avatarInitials = "AV"
        ),
        StreamixUser(
            id = "USR-74102",
            username = "sarah_miller",
            email = "smiller@example.com",
            tier = SubscriptionTier.FAMILY,
            status = UserStatus.ACTIVE,
            joinedDate = "Feb 04, 2026",
            streamHours = 210.2,
            ipCountry = "Canada",
            devicesCount = 5,
            avatarInitials = "SM"
        ),
        StreamixUser(
            id = "USR-63914",
            username = "david_kline",
            email = "dkline99@example.com",
            tier = SubscriptionTier.PLUS,
            status = UserStatus.ACTIVE,
            joinedDate = "Mar 18, 2026",
            streamHours = 94.0,
            ipCountry = "United Kingdom",
            devicesCount = 2,
            avatarInitials = "DK"
        ),
        StreamixUser(
            id = "USR-51208",
            username = "elena_rostova",
            email = "elena.rostova@example.com",
            tier = SubscriptionTier.FREE,
            status = UserStatus.ACTIVE,
            joinedDate = "May 22, 2026",
            streamHours = 45.3,
            ipCountry = "Germany",
            devicesCount = 1,
            avatarInitials = "ER"
        ),
        StreamixUser(
            id = "USR-40192",
            username = "toxic_streamer",
            email = "shadow_spammer@tempmail.com",
            tier = SubscriptionTier.FREE,
            status = UserStatus.BANNED,
            joinedDate = "Jun 01, 2026",
            streamHours = 2.1,
            ipCountry = "Unknown (Proxy/VPN)",
            devicesCount = 1,
            avatarInitials = "TS",
            banReason = "Repeated copyright infringement and spam botting in live chat"
        ),
        StreamixUser(
            id = "USR-39281",
            username = "marcus_chen",
            email = "mchen@techstream.org",
            tier = SubscriptionTier.ULTRA_4K,
            status = UserStatus.ACTIVE,
            joinedDate = "Jun 14, 2026",
            streamHours = 512.8,
            ipCountry = "Singapore",
            devicesCount = 3,
            avatarInitials = "MC"
        ),
        StreamixUser(
            id = "USR-28471",
            username = "lucas_silva",
            email = "lucas.silva@example.com",
            tier = SubscriptionTier.PLUS,
            status = UserStatus.SUSPENDED,
            joinedDate = "Jul 03, 2026",
            streamHours = 38.0,
            ipCountry = "Brazil",
            devicesCount = 2,
            avatarInitials = "LS",
            banReason = "Payment dispute pending verification"
        )
    ))
    val users: StateFlow<List<StreamixUser>> = _users.asStateFlow()

    // --- User Requests ---
    private val _requests = MutableStateFlow<List<UserRequest>>(listOf(
        UserRequest(
            id = "REQ-1049",
            userId = "USR-88219",
            userName = "alex_vortex",
            userEmail = "alex.vortex@example.com",
            type = RequestType.CONTENT_REQUEST,
            priority = RequestPriority.HIGH,
            status = RequestStatus.PENDING,
            title = "Request: Add 'Interstellar 4K IMAX Remaster'",
            description = "Could you add the 4K IMAX remastered edition with Dolby Atmos sound mix? Many sci-fi community members are requesting this.",
            submittedAt = "Today at 14:20"
        ),
        UserRequest(
            id = "REQ-1048",
            userId = "USR-39281",
            userName = "marcus_chen",
            userEmail = "mchen@techstream.org",
            type = RequestType.STREAM_QUALITY,
            priority = RequestPriority.URGENT,
            status = RequestStatus.IN_REVIEW,
            title = "Buffering stutter on 4K HDR stream via Apple TV",
            description = "Transcoding bitrate drops sharply on Server Node AP-East-2 during peak hours 8pm-10pm SGT.",
            submittedAt = "Today at 11:05"
        ),
        UserRequest(
            id = "REQ-1045",
            userId = "USR-74102",
            userName = "sarah_miller",
            userEmail = "smiller@example.com",
            type = RequestType.BILLING_SUPPORT,
            priority = RequestPriority.NORMAL,
            status = RequestStatus.PENDING,
            title = "Invoice discrepancy for annual Family plan renewal",
            description = "My invoice was charged standard rate without applying the promo coupon code SUMMER26.",
            submittedAt = "Yesterday at 18:40"
        ),
        UserRequest(
            id = "REQ-1042",
            userId = "USR-63914",
            userName = "david_kline",
            userEmail = "dkline99@example.com",
            type = RequestType.FEATURE_SUGGESTION,
            priority = RequestPriority.LOW,
            status = RequestStatus.APPROVED,
            title = "Watch Party synchronized audio chat",
            description = "Allow users in a private room to talk with low-latency audio while streaming movies together.",
            submittedAt = "Aug 14, 2026",
            adminResponse = "Passed to roadmap for Q4 Streamix v2.6 release.",
            resolvedBy = "Admin Super"
        ),
        UserRequest(
            id = "REQ-1039",
            userId = "USR-51208",
            userName = "elena_rostova",
            userEmail = "elena.rostova@example.com",
            type = RequestType.ACCOUNT_ISSUE,
            priority = RequestPriority.NORMAL,
            status = RequestStatus.REJECTED,
            title = "Request to transfer watch history to secondary account",
            description = "Want to merge 2 accounts without verifying previous primary email.",
            submittedAt = "Aug 12, 2026",
            adminResponse = "Rejected due to security policy: Email verification from both accounts is required.",
            resolvedBy = "Moderator Lead"
        )
    ))
    val requests: StateFlow<List<UserRequest>> = _requests.asStateFlow()

    // --- Media Content ---
    private val _contents = MutableStateFlow<List<MediaContent>>(listOf(
        MediaContent(
            id = "MED-7701",
            title = "Cyber Odyssey: 2099",
            type = ContentType.MOVIE,
            genre = "Sci-Fi / Cyberpunk",
            resolution = "4K HDR Dolby Vision",
            releaseYear = 2025,
            durationOrEpisodes = "2h 34m",
            viewsCount = 142850,
            rating = 4.9,
            status = ContentStatus.PUBLISHED,
            isFeatured = true,
            streamUrl = "https://cdn.streamix.cloud/vod/cyber_odyssey_4k.m3u8",
            addedDate = "Jul 10, 2026"
        ),
        MediaContent(
            id = "MED-7702",
            title = "Chronicles of the Void",
            type = ContentType.TV_SERIES,
            genre = "Fantasy / Drama",
            resolution = "4K HDR",
            releaseYear = 2026,
            durationOrEpisodes = "Season 1 (10 Eps)",
            viewsCount = 98400,
            rating = 4.7,
            status = ContentStatus.PUBLISHED,
            isFeatured = true,
            streamUrl = "https://cdn.streamix.cloud/vod/void_chronicles/manifest.m3u8",
            addedDate = "Aug 01, 2026"
        ),
        MediaContent(
            id = "MED-7703",
            title = "Apex Esports Grand Finals - Live 4K",
            type = ContentType.LIVE_STREAM,
            genre = "Gaming / Tournament",
            resolution = "4K 60FPS",
            releaseYear = 2026,
            durationOrEpisodes = "Live",
            viewsCount = 38900,
            rating = 4.8,
            status = ContentStatus.PUBLISHED,
            isFeatured = false,
            streamUrl = "https://live.streamix.cloud/hls/apex_finals/index.m3u8",
            addedDate = "Today"
        ),
        MediaContent(
            id = "MED-7704",
            title = "The Deepest Trench: Secrets of Mariana",
            type = ContentType.DOCUMENTARY,
            genre = "Nature / Ocean",
            resolution = "1080p FHD",
            releaseYear = 2024,
            durationOrEpisodes = "1h 48m",
            viewsCount = 42100,
            rating = 4.6,
            status = ContentStatus.PUBLISHED,
            isFeatured = false,
            streamUrl = "https://cdn.streamix.cloud/vod/mariana_trench.mp4",
            addedDate = "Jun 20, 2026"
        ),
        MediaContent(
            id = "MED-7705",
            title = "Neo Tokyo: Protocol Zero",
            type = ContentType.ANIME,
            genre = "Action / Animation",
            resolution = "1080p FHD 60FPS",
            releaseYear = 2026,
            durationOrEpisodes = "Season 1 (12 Eps)",
            viewsCount = 61200,
            rating = 4.9,
            status = ContentStatus.DRAFT,
            isFeatured = false,
            streamUrl = "https://cdn.streamix.cloud/staging/protocol_zero.m3u8",
            addedDate = "Aug 15, 2026"
        )
    ))
    val contents: StateFlow<List<MediaContent>> = _contents.asStateFlow()

    // --- Announcements ---
    private val _announcements = MutableStateFlow<List<Announcement>>(listOf(
        Announcement(
            id = "ANN-301",
            title = "Scheduled Server Maintenance Notice",
            message = "We will be upgrading CDN Transcoder clusters on August 22 from 02:00 UTC to 04:00 UTC. Live stream playback might experience brief interruptions.",
            audience = TargetAudience.ALL_USERS,
            priority = AnnouncementPriority.UPDATE,
            status = AnnouncementStatus.ACTIVE,
            createdAt = "Aug 16, 2026",
            expiresAt = "Aug 23, 2026",
            readCount = 31200
        ),
        Announcement(
            id = "ANN-302",
            title = "Exclusive Premiere: Cyber Odyssey 4K HDR",
            message = "Streamix Ultra subscribers can now stream Cyber Odyssey in full Dolby Vision with spatial audio.",
            audience = TargetAudience.PREMIUM_ONLY,
            priority = AnnouncementPriority.PROMO,
            status = AnnouncementStatus.ACTIVE,
            createdAt = "Aug 10, 2026",
            expiresAt = "Aug 30, 2026",
            actionUrl = "streamix://content/MED-7701",
            readCount = 18450
        ),
        Announcement(
            id = "ANN-303",
            title = "Upgrade to Ultra 4K - 30% Off Annual Pass",
            message = "Use code STREAMIX30 to upgrade your account and unlock 4 simultaneous screens and lossless audio.",
            audience = TargetAudience.FREE_TIER,
            priority = AnnouncementPriority.PROMO,
            status = AnnouncementStatus.ACTIVE,
            createdAt = "Aug 01, 2026",
            expiresAt = "Sep 01, 2026",
            readCount = 42800
        )
    ))
    val announcements: StateFlow<List<Announcement>> = _announcements.asStateFlow()

    // --- Premium Plans & Promo Codes ---
    private val _plans = MutableStateFlow<List<PremiumPlan>>(listOf(
        PremiumPlan(
            id = "PLAN-PLUS",
            name = "Streamix Plus",
            priceMonthly = 7.99,
            priceYearly = 79.99,
            maxScreens = 2,
            maxResolution = "1080p Full HD",
            audioQuality = "Stereo & 5.1 Surround",
            activeSubscribers = 18400,
            features = listOf("Ad-free streaming", "Offline downloads on 2 devices", "Access to standard catalog", "HD live streams"),
            isPopular = false,
            isEnabled = true
        ),
        PremiumPlan(
            id = "PLAN-ULTRA",
            name = "Streamix Ultra 4K",
            priceMonthly = 14.99,
            priceYearly = 149.99,
            maxScreens = 4,
            maxResolution = "4K UHD + HDR / Dolby Vision",
            audioQuality = "Dolby Atmos & Spatial Audio",
            activeSubscribers = 24100,
            features = listOf("Unlimited 4K HDR streaming", "Dolby Atmos Lossless Audio", "Offline downloads on 6 devices", "VIP Early Access premieres", "4 Concurrent Screens"),
            isPopular = true,
            isEnabled = true
        ),
        PremiumPlan(
            id = "PLAN-FAMILY",
            name = "Streamix Family Pass",
            priceMonthly = 19.99,
            priceYearly = 199.99,
            maxScreens = 6,
            maxResolution = "4K UHD + HDR",
            audioQuality = "Dolby Atmos",
            activeSubscribers = 6420,
            features = listOf("6 Individual profiles with parental controls", "Simultaneous streaming on 6 screens", "Kids safe hub", "Shared watchlist & party sync"),
            isPopular = false,
            isEnabled = true
        )
    ))
    val plans: StateFlow<List<PremiumPlan>> = _plans.asStateFlow()

    private val _promoCodes = MutableStateFlow<List<PromoCode>>(listOf(
        PromoCode(
            id = "PRM-901",
            code = "STREAMIX30",
            discountPercent = 30,
            applicablePlan = "All Plans",
            maxRedemptions = 5000,
            redeemedCount = 2140,
            expiresAt = "Sep 01, 2026",
            isActive = true
        ),
        PromoCode(
            id = "PRM-902",
            code = "VIPULTRA50",
            discountPercent = 50,
            applicablePlan = "Streamix Ultra 4K",
            maxRedemptions = 1000,
            redeemedCount = 890,
            expiresAt = "Aug 31, 2026",
            isActive = true
        ),
        PromoCode(
            id = "PRM-903",
            code = "SUMMER26",
            discountPercent = 20,
            applicablePlan = "Streamix Plus",
            maxRedemptions = 10000,
            redeemedCount = 6800,
            expiresAt = "Aug 31, 2026",
            isActive = true
        )
    ))
    val promoCodes: StateFlow<List<PromoCode>> = _promoCodes.asStateFlow()

    // --- Audit Logs ---
    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(listOf(
        AuditLogEntry(
            id = "AUD-991",
            timestamp = "Today 15:10",
            adminName = "SuperAdmin",
            action = "UPDATED_STREAM_BITRATE",
            target = "MED-7701 (Cyber Odyssey)",
            ipAddress = "192.168.1.104"
        ),
        AuditLogEntry(
            id = "AUD-990",
            timestamp = "Today 13:45",
            adminName = "ContentManager",
            action = "PUBLISHED_CONTENT",
            target = "MED-7703 (Apex Grand Finals)",
            ipAddress = "10.0.4.12"
        ),
        AuditLogEntry(
            id = "AUD-989",
            timestamp = "Yesterday 20:12",
            adminName = "ModeratorLead",
            action = "BANNED_USER",
            target = "USR-40192 (toxic_streamer)",
            ipAddress = "172.16.0.88"
        )
    ))
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    // --- Actions: Users ---
    fun updateUserStatus(userId: String, newStatus: UserStatus, banReason: String? = null) {
        _users.value = _users.value.map { user ->
            if (user.id == userId) {
                user.copy(status = newStatus, banReason = banReason)
            } else user
        }
        addAuditLog("USER_STATUS_CHANGE", "$userId -> ${newStatus.label}")
    }

    fun updateUserTier(userId: String, newTier: SubscriptionTier) {
        _users.value = _users.value.map { user ->
            if (user.id == userId) {
                user.copy(tier = newTier)
            } else user
        }
        addAuditLog("USER_TIER_CHANGE", "$userId -> ${newTier.label}")
    }

    // --- Actions: Requests ---
    fun updateRequestStatus(requestId: String, newStatus: RequestStatus, responseNote: String?, adminName: String) {
        _requests.value = _requests.value.map { req ->
            if (req.id == requestId) {
                req.copy(
                    status = newStatus,
                    adminResponse = responseNote ?: req.adminResponse,
                    resolvedBy = adminName
                )
            } else req
        }
        // Update pending count in telemetry
        val pending = _requests.value.count { it.status == RequestStatus.PENDING }
        _telemetry.value = _telemetry.value.copy(pendingRequests = pending)
        addAuditLog("RESOLVE_USER_REQUEST", "$requestId -> ${newStatus.label}")
    }

    // --- Actions: Content ---
    fun addContent(
        title: String,
        type: ContentType,
        genre: String,
        resolution: String,
        releaseYear: Int,
        duration: String,
        streamUrl: String,
        isFeatured: Boolean,
        status: ContentStatus = ContentStatus.PUBLISHED
    ) {
        val newContent = MediaContent(
            id = "MED-${(7700..9999).random()}",
            title = title,
            type = type,
            genre = genre,
            resolution = resolution,
            releaseYear = releaseYear,
            durationOrEpisodes = duration,
            viewsCount = 0,
            rating = 5.0,
            status = status,
            isFeatured = isFeatured,
            streamUrl = streamUrl,
            addedDate = "Just now"
        )
        _contents.value = listOf(newContent) + _contents.value
        addAuditLog("ADD_CONTENT", "${newContent.id} ($title)")
    }

    fun toggleContentStatus(contentId: String) {
        _contents.value = _contents.value.map { item ->
            if (item.id == contentId) {
                val newStatus = if (item.status == ContentStatus.PUBLISHED) ContentStatus.DRAFT else ContentStatus.PUBLISHED
                item.copy(status = newStatus)
            } else item
        }
        addAuditLog("TOGGLE_CONTENT_STATUS", contentId)
    }

    fun toggleContentFeatured(contentId: String) {
        _contents.value = _contents.value.map { item ->
            if (item.id == contentId) {
                item.copy(isFeatured = !item.isFeatured)
            } else item
        }
    }

    fun deleteContent(contentId: String) {
        _contents.value = _contents.value.filterNot { it.id == contentId }
        addAuditLog("DELETE_CONTENT", contentId)
    }

    // --- Actions: Announcements ---
    fun createAnnouncement(
        title: String,
        message: String,
        audience: TargetAudience,
        priority: AnnouncementPriority,
        expiresInDays: Int = 14,
        actionUrl: String? = null
    ) {
        val now = dateFormat.format(Date())
        val newAnn = Announcement(
            id = "ANN-${(310..999).random()}",
            title = title,
            message = message,
            audience = audience,
            priority = priority,
            status = AnnouncementStatus.ACTIVE,
            createdAt = now,
            expiresAt = "In $expiresInDays days",
            actionUrl = actionUrl,
            readCount = 0
        )
        _announcements.value = listOf(newAnn) + _announcements.value
        _telemetry.value = _telemetry.value.copy(activeAnnouncements = _announcements.value.count { it.status == AnnouncementStatus.ACTIVE })
        addAuditLog("CREATE_ANNOUNCEMENT", newAnn.id)
    }

    fun toggleAnnouncementStatus(announcementId: String) {
        _announcements.value = _announcements.value.map { ann ->
            if (ann.id == announcementId) {
                val newStatus = if (ann.status == AnnouncementStatus.ACTIVE) AnnouncementStatus.EXPIRED else AnnouncementStatus.ACTIVE
                ann.copy(status = newStatus)
            } else ann
        }
        _telemetry.value = _telemetry.value.copy(activeAnnouncements = _announcements.value.count { it.status == AnnouncementStatus.ACTIVE })
    }

    fun deleteAnnouncement(announcementId: String) {
        _announcements.value = _announcements.value.filterNot { it.id == announcementId }
        _telemetry.value = _telemetry.value.copy(activeAnnouncements = _announcements.value.count { it.status == AnnouncementStatus.ACTIVE })
        addAuditLog("DELETE_ANNOUNCEMENT", announcementId)
    }

    // --- Actions: Premium & Promos ---
    fun togglePlanStatus(planId: String) {
        _plans.value = _plans.value.map { plan ->
            if (plan.id == planId) plan.copy(isEnabled = !plan.isEnabled) else plan
        }
        addAuditLog("TOGGLE_PLAN_ENABLED", planId)
    }

    fun createPromoCode(code: String, discount: Int, planName: String, maxRedemptions: Int, expiry: String) {
        val newPromo = PromoCode(
            id = "PRM-${(910..999).random()}",
            code = code.uppercase().trim(),
            discountPercent = discount,
            applicablePlan = planName,
            maxRedemptions = maxRedemptions,
            redeemedCount = 0,
            expiresAt = expiry,
            isActive = true
        )
        _promoCodes.value = listOf(newPromo) + _promoCodes.value
        addAuditLog("CREATE_PROMO_CODE", newPromo.code)
    }

    fun togglePromoActive(promoId: String) {
        _promoCodes.value = _promoCodes.value.map { promo ->
            if (promo.id == promoId) promo.copy(isActive = !promo.isActive) else promo
        }
    }

    fun deletePromoCode(promoId: String) {
        _promoCodes.value = _promoCodes.value.filterNot { it.id == promoId }
        addAuditLog("DELETE_PROMO_CODE", promoId)
    }

    fun refreshTelemetry() {
        // Simulates real-time telemetry jitter from Streamix server node cluster
        val current = _telemetry.value
        _telemetry.value = current.copy(
            activeStreamers = current.activeStreamers + (-15..25).random(),
            apiLatencyMs = (22..35).random(),
            cpuUsagePercent = (38..52).random(),
            ramUsagePercent = (64..72).random()
        )
    }

    private fun addAuditLog(action: String, target: String) {
        val now = dateFormat.format(Date())
        val entry = AuditLogEntry(
            id = "AUD-${(1000..9999).random()}",
            timestamp = now,
            adminName = "SuperAdmin",
            action = action,
            target = target,
            ipAddress = "127.0.0.1 (Direct Console)"
        )
        _auditLogs.value = listOf(entry) + _auditLogs.value.take(49)
    }
}
