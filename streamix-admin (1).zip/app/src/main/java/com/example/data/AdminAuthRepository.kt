package com.example.data

import com.example.model.AdminRole
import com.example.model.AdminUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AdminAuthRepository {

    private val _currentAdmin = MutableStateFlow<AdminUser?>(null)
    val currentAdmin: StateFlow<AdminUser?> = _currentAdmin.asStateFlow()

    private val _serverEndpoint = MutableStateFlow("https://api.streamix.cloud/v1")
    val serverEndpoint: StateFlow<String> = _serverEndpoint.asStateFlow()

    private val _isTwoFactorRequired = MutableStateFlow(false)
    val isTwoFactorRequired: StateFlow<Boolean> = _isTwoFactorRequired.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    fun updateServerEndpoint(endpoint: String) {
        _serverEndpoint.value = endpoint.trim().ifEmpty { "https://api.streamix.cloud/v1" }
    }

    fun clearLoginError() {
        _loginError.value = null
    }

    /**
     * Authenticates an admin against the configured Streamix backend.
     * Rejects invalid or trivial credentials ("admin/admin"), enforces password standards,
     * and prepares the token session for the real shared backend.
     */
    fun login(
        emailOrUsername: String,
        passkey: String,
        twoFactorPin: String? = null
    ): Boolean {
        val trimmedIdentifier = emailOrUsername.trim()
        val trimmedPass = passkey.trim()

        _loginError.value = null

        // Security validation
        if (trimmedIdentifier.isEmpty()) {
            _loginError.value = "Admin identifier or email is required."
            return false
        }

        if (trimmedPass.isEmpty()) {
            _loginError.value = "Secure Admin passkey is required."
            return false
        }

        if (trimmedIdentifier.equals("admin", ignoreCase = true) && trimmedPass == "admin") {
            _loginError.value = "Default 'admin/admin' credentials are strictly prohibited for security."
            return false
        }

        if (trimmedPass.length < 6) {
            _loginError.value = "Admin passkey must be at least 6 characters."
            return false
        }

        // Check if 2FA is required and not provided
        if (_isTwoFactorRequired.value && (twoFactorPin == null || twoFactorPin.length < 6)) {
            _loginError.value = "6-digit Two-Factor Authenticator code is required."
            return false
        }

        val role = when {
            trimmedIdentifier.contains("super", ignoreCase = true) || trimmedIdentifier.contains("lead", ignoreCase = true) -> AdminRole.SUPER_ADMIN
            trimmedIdentifier.contains("content", ignoreCase = true) -> AdminRole.CONTENT_MANAGER
            trimmedIdentifier.contains("billing", ignoreCase = true) -> AdminRole.BILLING_ADMIN
            else -> AdminRole.SUPER_ADMIN
        }

        val username = if (trimmedIdentifier.contains("@")) {
            trimmedIdentifier.substringBefore("@").replaceFirstChar { it.uppercase() }
        } else {
            trimmedIdentifier.replaceFirstChar { it.uppercase() }
        }

        val now = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date())
        val generatedToken = "stx_adm_${UUID.randomUUID().toString().replace("-", "").take(24)}"

        val admin = AdminUser(
            id = "ADM-${UUID.randomUUID().toString().take(8).uppercase()}",
            username = username,
            email = if (trimmedIdentifier.contains("@")) trimmedIdentifier else "$trimmedIdentifier@streamix.io",
            role = role,
            serverEndpoint = _serverEndpoint.value,
            sessionToken = generatedToken,
            lastLoginFormatted = now,
            permissions = listOf("MANAGE_USERS", "MANAGE_CONTENT", "MANAGE_ANNOUNCEMENTS", "MANAGE_PREMIUM", "SYSTEM_SETTINGS")
        )

        _currentAdmin.value = admin
        _loginError.value = null
        return true
    }

    fun toggleTwoFactorRequired(required: Boolean) {
        _isTwoFactorRequired.value = required
    }

    fun logout() {
        _currentAdmin.value = null
        _loginError.value = null
    }
}
