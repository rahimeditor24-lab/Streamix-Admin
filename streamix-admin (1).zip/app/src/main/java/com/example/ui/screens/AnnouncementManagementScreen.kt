package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Announcement
import com.example.model.AnnouncementPriority
import com.example.model.AnnouncementStatus
import com.example.model.TargetAudience
import com.example.ui.AdminViewModel
import com.example.ui.components.EmptyListCard
import com.example.ui.theme.*

@Composable
fun AnnouncementManagementScreen(
    viewModel: AdminViewModel,
    modifier: Modifier = Modifier
) {
    val announcements by viewModel.filteredAnnouncements.collectAsState()
    val rawAnnouncements by viewModel.rawAnnouncements.collectAsState()
    val currentStatusFilter by viewModel.announcementStatusFilter.collectAsState()

    var showCreateModal by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("announcement_management_screen_root")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Header Action
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Broadcast Notifications",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.2.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "In-app alerts & push broadcasts for Streamix clients",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { showCreateModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StreamixRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("create_announcement_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Broadcast", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = currentStatusFilter == null,
                            onClick = { viewModel.setAnnouncementStatusFilter(null) },
                            label = { Text("All (${rawAnnouncements.size})", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = currentStatusFilter == null,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                    items(AnnouncementStatus.entries) { status ->
                        val isSelected = currentStatusFilter == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setAnnouncementStatusFilter(status) },
                            label = { Text(status.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                }
            }

            // Announcement Items
            if (announcements.isEmpty()) {
                item {
                    EmptyListCard(
                        title = "No Announcements Found",
                        subtitle = "Click '+ New Broadcast' above to push an alert to Streamix users."
                    )
                }
            } else {
                items(announcements, key = { it.id }) { ann ->
                    AnnouncementCard(
                        announcement = ann,
                        onToggleStatus = {
                            viewModel.toggleAnnouncementStatus(ann.id)
                            snackbarMessage = "Toggled status for ${ann.id}"
                        },
                        onDelete = {
                            viewModel.deleteAnnouncement(ann.id)
                            snackbarMessage = "Deleted announcement ${ann.id}"
                        }
                    )
                }
            }
        }

        // Create Announcement Modal
        if (showCreateModal) {
            CreateAnnouncementModal(
                onDismiss = { showCreateModal = false },
                onConfirm = { title, msg, audience, priority, days, url ->
                    viewModel.createAnnouncement(title, msg, audience, priority, days, url)
                    showCreateModal = false
                    snackbarMessage = "Broadcast published to ${audience.label}"
                }
            )
        }

        // Toast Feedback
        snackbarMessage?.let { msg ->
            Snackbar(
                action = { TextButton(onClick = { snackbarMessage = null }) { Text("OK", color = StreamixRedLight, fontWeight = FontWeight.Bold) } },
                containerColor = DarkSurfaceElevated,
                contentColor = TextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Text(msg)
            }
        }
    }
}

@Composable
private fun AnnouncementCard(
    announcement: Announcement,
    onToggleStatus: () -> Unit,
    onDelete: () -> Unit
) {
    val (priorityColor, priorityBg) = when (announcement.priority) {
        AnnouncementPriority.URGENT -> Pair(StreamixRedLight, StreamixRed.copy(alpha = 0.15f))
        AnnouncementPriority.PROMO -> Pair(PurpleBadge, PurpleBadge.copy(alpha = 0.15f))
        AnnouncementPriority.UPDATE -> Pair(CyanAccent, CyanAccent.copy(alpha = 0.15f))
        AnnouncementPriority.INFO -> Pair(InfoSky, InfoSky.copy(alpha = 0.15f))
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Priority Tag & Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(priorityBg)
                            .border(1.dp, priorityColor.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = announcement.priority.label.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = priorityColor
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurfaceElevated)
                            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = announcement.audience.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (announcement.status == AnnouncementStatus.ACTIVE) SuccessEmerald.copy(alpha = 0.15f) else TextTertiary.copy(alpha = 0.15f),
                    modifier = Modifier.border(
                        1.dp,
                        if (announcement.status == AnnouncementStatus.ACTIVE) SuccessEmerald.copy(alpha = 0.35f) else DarkSurfaceBorder,
                        RoundedCornerShape(10.dp)
                    )
                ) {
                    Text(
                        text = announcement.status.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (announcement.status == AnnouncementStatus.ACTIVE) SuccessEmerald else TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = announcement.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = announcement.message,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Footer info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Posted: ${announcement.createdAt} • Expires: ${announcement.expiresAt}",
                    fontSize = 11.sp,
                    color = TextTertiary
                )
                Text(
                    text = "${announcement.readCount} views",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onToggleStatus,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (announcement.status == AnnouncementStatus.ACTIVE) "Expire / Disable" else "Reactivate",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceElevated)
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRose)
                }
            }
        }
    }
}

@Composable
private fun CreateAnnouncementModal(
    onDismiss: () -> Unit,
    onConfirm: (String, String, TargetAudience, AnnouncementPriority, Int, String?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var selectedAudience by remember { mutableStateOf(TargetAudience.ALL_USERS) }
    var selectedPriority by remember { mutableStateOf(AnnouncementPriority.UPDATE) }
    var expiryDays by remember { mutableStateOf("14") }
    var actionUrl by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        titleContentColor = TextPrimary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(StreamixRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Compose Broadcast Alert", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notification Title") },
                    placeholder = { Text("e.g., Scheduled Maintenance Window") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Message Body") },
                    placeholder = { Text("Detailed notice text...") },
                    singleLine = false,
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Target Audience", fontSize = 12.sp, color = TextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(TargetAudience.entries) { aud ->
                        FilterChip(
                            selected = selectedAudience == aud,
                            onClick = { selectedAudience = aud },
                            label = { Text(aud.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                Text("Priority Tag", fontSize = 12.sp, color = TextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(AnnouncementPriority.entries) { pri ->
                        FilterChip(
                            selected = selectedPriority == pri,
                            onClick = { selectedPriority = pri },
                            label = { Text(pri.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = expiryDays,
                    onValueChange = { expiryDays = it },
                    label = { Text("Expires In (Days)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && message.isNotBlank()) {
                        val parsedDays = expiryDays.toIntOrNull() ?: 14
                        onConfirm(title, message, selectedAudience, selectedPriority, parsedDays, actionUrl.ifBlank { null })
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StreamixRed)
            ) {
                Text("Broadcast Live", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}
