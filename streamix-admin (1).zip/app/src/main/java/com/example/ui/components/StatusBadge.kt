package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun UserStatusBadge(status: UserStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, dotColor) = when (status) {
        UserStatus.ACTIVE -> Triple(SuccessEmerald.copy(alpha = 0.12f), SuccessEmerald, SuccessEmerald)
        UserStatus.SUSPENDED -> Triple(WarningAmber.copy(alpha = 0.12f), WarningAmber, WarningAmber)
        UserStatus.BANNED -> Triple(StreamixRed.copy(alpha = 0.15f), StreamixRedLight, StreamixRed)
        UserStatus.PENDING_VERIFICATION -> Triple(InfoSky.copy(alpha = 0.12f), InfoSky, InfoSky)
    }

    GlassBadgeContainer(label = status.label, bgColor = bgColor, textColor = textColor, dotColor = dotColor, modifier = modifier)
}

@Composable
fun TierBadge(tier: SubscriptionTier, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (tier) {
        SubscriptionTier.FREE -> Triple(DarkSurfaceElevated, TextSecondary, DarkSurfaceBorder)
        SubscriptionTier.PLUS -> Triple(InfoSky.copy(alpha = 0.12f), InfoSky, InfoSky.copy(alpha = 0.3f))
        SubscriptionTier.FAMILY -> Triple(CyanAccent.copy(alpha = 0.12f), CyanAccent, CyanAccent.copy(alpha = 0.3f))
        SubscriptionTier.ULTRA_4K -> Triple(StreamixRed.copy(alpha = 0.18f), StreamixRedLight, StreamixRed.copy(alpha = 0.5f))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(
            text = tier.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.3.sp
        )
    }
}

@Composable
fun RequestStatusBadge(status: RequestStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, dotColor) = when (status) {
        RequestStatus.PENDING -> Triple(WarningAmber.copy(alpha = 0.15f), WarningAmber, WarningAmber)
        RequestStatus.IN_REVIEW -> Triple(CyanAccent.copy(alpha = 0.15f), CyanAccent, CyanAccent)
        RequestStatus.APPROVED -> Triple(SuccessEmerald.copy(alpha = 0.15f), SuccessEmerald, SuccessEmerald)
        RequestStatus.REJECTED -> Triple(StreamixRed.copy(alpha = 0.15f), StreamixRedLight, StreamixRed)
    }

    GlassBadgeContainer(label = status.label, bgColor = bgColor, textColor = textColor, dotColor = dotColor, modifier = modifier)
}

@Composable
fun RequestPriorityBadge(priority: RequestPriority, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (priority) {
        RequestPriority.LOW -> Triple(DarkSurfaceElevated, TextTertiary, DarkSurfaceBorder)
        RequestPriority.NORMAL -> Triple(InfoSky.copy(alpha = 0.12f), InfoSky, InfoSky.copy(alpha = 0.3f))
        RequestPriority.HIGH -> Triple(WarningAmber.copy(alpha = 0.15f), WarningAmber, WarningAmber.copy(alpha = 0.4f))
        RequestPriority.URGENT -> Triple(StreamixRed.copy(alpha = 0.2f), StreamixRedLight, StreamixRed.copy(alpha = 0.6f))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(
            text = priority.label.uppercase(),
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun ContentStatusBadge(status: ContentStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, dotColor) = when (status) {
        ContentStatus.PUBLISHED -> Triple(SuccessEmerald.copy(alpha = 0.15f), SuccessEmerald, SuccessEmerald)
        ContentStatus.DRAFT -> Triple(DarkSurfaceElevated, TextSecondary, TextTertiary)
        ContentStatus.SCHEDULED -> Triple(InfoSky.copy(alpha = 0.15f), InfoSky, InfoSky)
        ContentStatus.FLAGGED -> Triple(StreamixRed.copy(alpha = 0.15f), StreamixRedLight, StreamixRed)
    }

    GlassBadgeContainer(label = status.label, bgColor = bgColor, textColor = textColor, dotColor = dotColor, modifier = modifier)
}

@Composable
private fun GlassBadgeContainer(
    label: String,
    bgColor: Color,
    textColor: Color,
    dotColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
