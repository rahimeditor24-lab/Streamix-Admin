package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StreamixUser
import com.example.model.SubscriptionTier
import com.example.model.UserStatus
import com.example.ui.AdminViewModel
import com.example.ui.components.EmptyListCard
import com.example.ui.components.TierBadge
import com.example.ui.components.UserStatusBadge
import com.example.ui.theme.*

@Composable
fun UserManagementScreen(
    viewModel: AdminViewModel,
    modifier: Modifier = Modifier
) {
    val users by viewModel.filteredUsers.collectAsState()
    val rawUsers by viewModel.rawUsers.collectAsState()
    val searchQuery by viewModel.userSearchQuery.collectAsState()
    val statusFilter by viewModel.userStatusFilter.collectAsState()

    var selectedUserForEdit by remember { mutableStateOf<StreamixUser?>(null) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("user_management_screen_root")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Search Bar with Streamix Red Accent
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setUserSearchQuery(it) },
                    placeholder = { Text("Search users by name, email, or account ID...", color = TextTertiary, fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = if (searchQuery.isNotEmpty()) StreamixRedLight else TextTertiary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setUserSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("user_search_input")
                )
            }

            // Status Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = statusFilter == null,
                            onClick = { viewModel.setUserStatusFilter(null) },
                            label = { Text("All Users (${rawUsers.size})", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = statusFilter == null,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                    items(UserStatus.entries) { status ->
                        val isSelected = statusFilter == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setUserStatusFilter(status) },
                            label = { Text(status.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                }
            }

            // User Items
            if (users.isEmpty()) {
                item {
                    EmptyListCard(
                        title = "No Users Found",
                        subtitle = "Try adjusting your search criteria or status filter."
                    )
                }
            } else {
                items(users, key = { it.id }) { user ->
                    UserItemCard(
                        user = user,
                        onClick = { selectedUserForEdit = user }
                    )
                }
            }
        }

        // Edit User Dialog
        selectedUserForEdit?.let { user ->
            UserModerationDialog(
                user = user,
                onDismiss = { selectedUserForEdit = null },
                onSaveStatus = { newStatus, reason ->
                    viewModel.updateUserStatus(user.id, newStatus, reason)
                    selectedUserForEdit = null
                    snackbarMessage = "Updated ${user.username}'s status to ${newStatus.label}"
                },
                onSaveTier = { newTier ->
                    viewModel.updateUserTier(user.id, newTier)
                    selectedUserForEdit = null
                    snackbarMessage = "Upgraded ${user.username}'s plan to ${newTier.label}"
                }
            )
        }

        // Toast Feedback
        snackbarMessage?.let { msg ->
            Snackbar(
                action = {
                    TextButton(onClick = { snackbarMessage = null }) {
                        Text("OK", color = StreamixRedLight, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = DarkSurfaceElevated,
                contentColor = TextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Text(msg)
            }
        }
    }
}

@Composable
private fun UserItemCard(
    user: StreamixUser,
    onClick: () -> Unit
) {
    val tierColor = when (user.tier) {
        SubscriptionTier.ULTRA_4K -> StreamixRed
        SubscriptionTier.FAMILY -> CyanAccent
        SubscriptionTier.PLUS -> InfoSky
        SubscriptionTier.FREE -> TextTertiary
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(tierColor.copy(alpha = 0.3f), DarkSurfaceElevated)
                                )
                            )
                            .border(1.5.dp, tierColor.copy(alpha = 0.6f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.avatarInitials.ifEmpty { user.username.take(1).uppercase() },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user.username,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = user.email,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                UserStatusBadge(status = user.status)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Specs Row (Tier, Devices, Watch hours)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurfaceElevated)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TierBadge(tier = user.tier)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${user.devicesCount} devices",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                Text(
                    text = "%.1f hrs watched".format(user.streamHours),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Joined: ${user.joinedDate} • ${user.ipCountry}",
                    fontSize = 11.sp,
                    color = TextTertiary
                )
                Text(
                    text = "Tap to Moderate",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = StreamixRedLight
                )
            }
        }
    }
}

@Composable
private fun UserModerationDialog(
    user: StreamixUser,
    onDismiss: () -> Unit,
    onSaveStatus: (UserStatus, String) -> Unit,
    onSaveTier: (SubscriptionTier) -> Unit
) {
    var selectedStatus by remember { mutableStateOf(user.status) }
    var selectedTier by remember { mutableStateOf(user.tier) }
    var reasonNote by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        titleContentColor = TextPrimary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(StreamixRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Manage: ${user.username}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                Text("User ID: ${user.id} • ${user.email}", fontSize = 12.sp, color = TextSecondary)

                // Plan Upgrade Section
                Text("Subscription Tier", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(SubscriptionTier.entries) { tier ->
                        FilterChip(
                            selected = selectedTier == tier,
                            onClick = { selectedTier = tier },
                            label = { Text(tier.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                // Account Status Section
                Text("Account Moderation Status", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(UserStatus.entries) { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = st },
                            label = { Text(st.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (st == UserStatus.BANNED) StreamixRed else InfoSky,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                if (selectedStatus == UserStatus.BANNED || selectedStatus == UserStatus.SUSPENDED) {
                    OutlinedTextField(
                        value = reasonNote,
                        onValueChange = { reasonNote = it },
                        label = { Text("Administrative Reason (Required)") },
                        placeholder = { Text("e.g., Exceeded account screen limits or Terms violation") },
                        singleLine = false,
                        maxLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StreamixRed,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedTier != user.tier) {
                        onSaveTier(selectedTier)
                    }
                    if (selectedStatus != user.status) {
                        onSaveStatus(selectedStatus, reasonNote.ifBlank { "Updated by Administrator" })
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StreamixRed)
            ) {
                Text("Save Changes", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
