package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AdminUser
import com.example.ui.components.AdminTopBar
import com.example.ui.navigation.AdminScreen
import com.example.ui.screens.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StreamixAdminApp(
    viewModel: AdminViewModel = viewModel()
) {
    val currentAdmin by viewModel.currentAdmin.collectAsState()
    var currentScreen by remember { mutableStateOf(AdminScreen.DASHBOARD) }

    // When logged out, reset to dashboard route
    LaunchedEffect(currentAdmin) {
        if (currentAdmin == null) {
            currentScreen = AdminScreen.LOGIN
        } else if (currentScreen == AdminScreen.LOGIN) {
            currentScreen = AdminScreen.DASHBOARD
        }
    }

    if (currentAdmin == null) {
        LoginScreen(
            viewModel = viewModel,
            onLoginSuccess = {
                currentScreen = AdminScreen.DASHBOARD
            }
        )
    } else {
        // Handle Back button
        BackHandler(enabled = currentScreen != AdminScreen.DASHBOARD) {
            currentScreen = AdminScreen.DASHBOARD
        }

        Scaffold(
            topBar = {
                AdminTopBar(
                    title = currentScreen.title,
                    adminUser = currentAdmin,
                    canNavigateBack = currentScreen != AdminScreen.DASHBOARD,
                    onNavigateBack = { currentScreen = AdminScreen.DASHBOARD },
                    onOpenSettings = { currentScreen = AdminScreen.SETTINGS },
                    onLogoutClick = { viewModel.logout() }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurfaceGlass,
                    contentColor = TextPrimary,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .border(0.5.dp, DarkSurfaceBorder, RoundedCornerShape(0.dp))
                        .testTag("admin_bottom_navigation")
                ) {
                    val bottomItems = listOf(
                        AdminScreen.DASHBOARD,
                        AdminScreen.USERS,
                        AdminScreen.REQUESTS,
                        AdminScreen.CONTENT,
                        AdminScreen.ANNOUNCEMENTS,
                        AdminScreen.PREMIUM
                    )

                    bottomItems.forEach { screen ->
                        val isSelected = currentScreen == screen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = screen },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = when (screen) {
                                        AdminScreen.DASHBOARD -> "Dashboard"
                                        AdminScreen.USERS -> "Users"
                                        AdminScreen.REQUESTS -> "Requests"
                                        AdminScreen.CONTENT -> "Content"
                                        AdminScreen.ANNOUNCEMENTS -> "Broadcast"
                                        AdminScreen.PREMIUM -> "Premium"
                                        else -> screen.title
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = StreamixRedLight,
                                selectedTextColor = StreamixRedLight,
                                indicatorColor = StreamixRed.copy(alpha = 0.2f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextTertiary
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            },
            containerColor = ObsidianBg,
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                    },
                    label = "admin_screen_transition"
                ) { targetScreen ->
                    when (targetScreen) {
                        AdminScreen.DASHBOARD -> DashboardScreen(
                            viewModel = viewModel,
                            onNavigateToScreen = { target -> currentScreen = target }
                        )
                        AdminScreen.USERS -> UserManagementScreen(
                            viewModel = viewModel
                        )
                        AdminScreen.REQUESTS -> UserRequestsScreen(
                            viewModel = viewModel
                        )
                        AdminScreen.CONTENT -> ContentManagementScreen(
                            viewModel = viewModel
                        )
                        AdminScreen.ANNOUNCEMENTS -> AnnouncementManagementScreen(
                            viewModel = viewModel
                        )
                        AdminScreen.PREMIUM -> PremiumManagementScreen(
                            viewModel = viewModel
                        )
                        AdminScreen.SETTINGS -> SettingsScreen(
                            viewModel = viewModel,
                            onLogoutClick = { viewModel.logout() }
                        )
                        AdminScreen.LOGIN -> LoginScreen(
                            viewModel = viewModel,
                            onLoginSuccess = { currentScreen = AdminScreen.DASHBOARD }
                        )
                    }
                }
            }
        }
    }
}
