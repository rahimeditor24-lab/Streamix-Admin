package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Streamix Cinema Obsidian & Deep Charcoal Palette
val ObsidianBg = Color(0xFF07080B)
val CharcoalDark = Color(0xFF0D0E13)
val DarkSurface = Color(0xFF13151C)
val DarkSurfaceElevated = Color(0xFF1A1D27)
val DarkSurfaceGlass = Color(0xCC151720)
val DarkSurfaceBorder = Color(0xFF262A38)
val DarkSurfaceBorderLight = Color(0x33FFFFFF)
val DarkSurfaceHover = Color(0xFF202432)

// Streamix Brand Red Accents
val StreamixRed = Color(0xFFE50914)
val StreamixRedLight = Color(0xFFFF2E38)
val StreamixRedGlow = Color(0x33E50914)
val StreamixRedDark = Color(0xFF99060E)
val StreamixWine = Color(0xFF4A080C)

// Vibrant Supporting Accents
val CyanAccent = Color(0xFF00E5FF)
val CyanGlow = Color(0x3300E5FF)
val SuccessEmerald = Color(0xFF10B981)
val SuccessEmeraldGlow = Color(0x3310B981)
val WarningAmber = Color(0xFFF59E0B)
val DangerRose = Color(0xFFF43F5E)
val InfoSky = Color(0xFF38BDF8)
val PurpleBadge = Color(0xFFA855F7)

// Text & Monochromes
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9CA3AF)
val TextTertiary = Color(0xFF6B7280)
val TextMuted = Color(0xFF4B5563)

// Light Theme Fallbacks
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightSurfaceBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
