package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentStatus
import com.example.model.ContentType
import com.example.model.MediaContent
import com.example.ui.AdminViewModel
import com.example.ui.components.ContentStatusBadge
import com.example.ui.components.EmptyListCard
import com.example.ui.theme.*

@Composable
fun ContentManagementScreen(
    viewModel: AdminViewModel,
    modifier: Modifier = Modifier
) {
    val contents by viewModel.filteredContents.collectAsState()
    val rawContents by viewModel.rawContents.collectAsState()
    val currentTypeFilter by viewModel.contentTypeFilter.collectAsState()

    var showAddContentDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmFor by remember { mutableStateOf<MediaContent?>(null) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("content_management_screen_root")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Top action button & stats banner
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Catalog & Streams",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.2.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "${rawContents.size} media titles indexed",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { showAddContentDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StreamixRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("add_content_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Media", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Category Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = currentTypeFilter == null,
                            onClick = { viewModel.setContentTypeFilter(null) },
                            label = { Text("All (${rawContents.size})", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = currentTypeFilter == null,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                    items(ContentType.entries) { type ->
                        val isSelected = currentTypeFilter == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setContentTypeFilter(type) },
                            label = { Text(type.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                }
            }

            // Content List
            if (contents.isEmpty()) {
                item {
                    EmptyListCard(
                        title = "No Content In Category",
                        subtitle = "Click '+ Add Media' above to publish or draft a new stream."
                    )
                }
            } else {
                items(contents, key = { it.id }) { item ->
                    MediaItemCard(
                        content = item,
                        onTogglePublish = {
                            viewModel.toggleContentStatus(item.id)
                            snackbarMessage = "Updated publish status for ${item.title}"
                        },
                        onToggleFeatured = {
                            viewModel.toggleContentFeatured(item.id)
                            snackbarMessage = if (!item.isFeatured) "Pinned as Featured Hero in User App" else "Removed from Featured"
                        },
                        onDelete = { showDeleteConfirmFor = item }
                    )
                }
            }
        }

        // Add Content Modal
        if (showAddContentDialog) {
            AddContentModal(
                onDismiss = { showAddContentDialog = false },
                onConfirm = { title, type, genre, res, year, duration, url, featured ->
                    viewModel.addContent(title, type, genre, res, year, duration, url, featured)
                    showAddContentDialog = false
                    snackbarMessage = "Indexed '$title' in Streamix catalog"
                }
            )
        }

        // Delete Confirm Dialog
        showDeleteConfirmFor?.let { media ->
            AlertDialog(
                onDismissRequest = { showDeleteConfirmFor = null },
                containerColor = DarkSurface,
                titleContentColor = DangerRose,
                title = { Text("Delete Streamix Media?") },
                text = {
                    Text(
                        "Are you sure you want to permanently delete '${media.title}' (${media.id})? This will immediately disable stream playback in the user app.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteContent(media.id)
                            showDeleteConfirmFor = null
                            snackbarMessage = "Deleted ${media.title}"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRose)
                    ) {
                        Text("Delete Stream", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmFor = null }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }

        // Toast Feedback
        snackbarMessage?.let { msg ->
            Snackbar(
                action = { TextButton(onClick = { snackbarMessage = null }) { Text("OK", color = StreamixRedLight, fontWeight = FontWeight.Bold) } },
                containerColor = DarkSurfaceElevated,
                contentColor = TextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Text(msg)
            }
        }
    }
}

@Composable
private fun MediaItemCard(
    content: MediaContent,
    onTogglePublish: () -> Unit,
    onToggleFeatured: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (content.isFeatured) StreamixRed.copy(alpha = 0.5f) else DarkSurfaceBorder,
                RoundedCornerShape(16.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = DarkSurfaceElevated,
                            modifier = Modifier.border(1.dp, DarkSurfaceBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text(
                                text = content.type.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        if (content.isFeatured) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = StreamixRed.copy(alpha = 0.2f),
                                modifier = Modifier.border(1.dp, StreamixRed.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            ) {
                                Text(
                                    text = "FEATURED HERO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    color = StreamixRedLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = content.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Text(
                        text = "${content.genre} • ${content.releaseYear} • ${content.durationOrEpisodes}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                ContentStatusBadge(status = content.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Specs Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurfaceElevated)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.HighQuality, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                Text(
                    text = content.resolution,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CyanAccent
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "%,d views".format(content.viewsCount),
                    fontSize = 11.sp,
                    color = TextTertiary
                )
                Text(
                    text = "★ ${content.rating}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = WarningAmber
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stream URL preview
            Text(
                text = "HLS/DASH: ${content.streamUrl}",
                fontSize = 10.sp,
                color = TextTertiary,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Actions Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onTogglePublish,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (content.status == ContentStatus.PUBLISHED) WarningAmber else SuccessEmerald
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (content.status == ContentStatus.PUBLISHED) "Unpublish (Draft)" else "Publish",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = onToggleFeatured,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceElevated)
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp))
                ) {
                    Icon(
                        imageVector = if (content.isFeatured) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Toggle Featured",
                        tint = if (content.isFeatured) StreamixRedLight else TextSecondary
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceElevated)
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = DangerRose
                    )
                }
            }
        }
    }
}

@Composable
private fun AddContentModal(
    onDismiss: () -> Unit,
    onConfirm: (String, ContentType, String, String, Int, String, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(ContentType.MOVIE) }
    var genre by remember { mutableStateOf("Action / Sci-Fi") }
    var resolution by remember { mutableStateOf("4K HDR Dolby Vision") }
    var releaseYear by remember { mutableStateOf("2026") }
    var duration by remember { mutableStateOf("2h 15m") }
    var streamUrl by remember { mutableStateOf("https://cdn.streamix.cloud/vod/sample.m3u8") }
    var isFeatured by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        titleContentColor = TextPrimary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(StreamixRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Index Streamix Media", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    placeholder = { Text("e.g., Dune 3: Messiah") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Content Type", fontSize = 12.sp, color = TextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ContentType.entries) { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = genre,
                    onValueChange = { genre = it },
                    label = { Text("Genre / Categories") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = resolution,
                        onValueChange = { resolution = it },
                        label = { Text("Resolution") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StreamixRed,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = releaseYear,
                        onValueChange = { releaseYear = it },
                        label = { Text("Year") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StreamixRed,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.weight(0.6f)
                    )
                }

                OutlinedTextField(
                    value = duration,
                    onValueChange = { duration = it },
                    label = { Text("Duration / Episodes") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = streamUrl,
                    onValueChange = { streamUrl = it },
                    label = { Text("Manifest Stream URL (HLS / DASH)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = isFeatured,
                        onCheckedChange = { isFeatured = it },
                        colors = CheckboxDefaults.colors(checkedColor = StreamixRed)
                    )
                    Text("Pin as Featured Hero Carousel in User App", fontSize = 12.sp, color = TextPrimary)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val parsedYear = releaseYear.toIntOrNull() ?: 2026
                        onConfirm(title, selectedType, genre, resolution, parsedYear, duration, streamUrl, isFeatured)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StreamixRed)
            ) {
                Text("Index into Catalog", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
