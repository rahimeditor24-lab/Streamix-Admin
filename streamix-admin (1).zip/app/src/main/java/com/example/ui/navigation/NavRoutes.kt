package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class AdminScreen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val isBottomBarItem: Boolean = true
) {
    DASHBOARD("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard, true),
    USERS("users", "User Management", Icons.Filled.People, Icons.Outlined.People, true),
    REQUESTS("requests", "User Requests", Icons.Filled.Assignment, Icons.Outlined.Assignment, true),
    CONTENT("content", "Content Catalog", Icons.Filled.Movie, Icons.Outlined.Movie, true),
    ANNOUNCEMENTS("announcements", "Announcements", Icons.Filled.Campaign, Icons.Outlined.Campaign, false),
    PREMIUM("premium", "Premium & Subscriptions", Icons.Filled.WorkspacePremium, Icons.Outlined.WorkspacePremium, false),
    SETTINGS("settings", "Admin Settings", Icons.Filled.Settings, Icons.Outlined.Settings, false),
    LOGIN("login", "Admin Authentication", Icons.Filled.Lock, Icons.Outlined.Lock, false);

    companion object {
        fun fromRoute(route: String?): AdminScreen {
            return entries.find { it.route == route } ?: DASHBOARD
        }
    }
}
