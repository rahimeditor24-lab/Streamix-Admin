package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = StreamixRed,
    onPrimary = Color.White,
    primaryContainer = StreamixRedDark,
    onPrimaryContainer = Color.White,
    secondary = StreamixRedLight,
    onSecondary = ObsidianBg,
    secondaryContainer = StreamixWine,
    onSecondaryContainer = StreamixRedLight,
    tertiary = CyanAccent,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkSurfaceBorder,
    error = DangerRose,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = StreamixRed,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE5E7),
    onPrimaryContainer = StreamixRedDark,
    secondary = CyanAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCFFAFE),
    onSecondaryContainer = Color(0xFF164E63),
    tertiary = PurpleBadge,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = LightTextSecondary,
    outline = LightSurfaceBorder,
    error = DangerRose,
    onError = Color.White
)

@Composable
fun StreamixAdminTheme(
    darkTheme: Boolean = true, // Premium Streamix OTT Admin is dark by default
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
