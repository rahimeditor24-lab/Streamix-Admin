package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RequestStatus
import com.example.ui.AdminViewModel
import com.example.ui.components.AdminStatCard
import com.example.ui.components.SectionHeader
import com.example.ui.navigation.AdminScreen
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: AdminViewModel,
    onNavigateToScreen: (AdminScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val telemetry by viewModel.telemetry.collectAsState()
    val rawUsers by viewModel.rawUsers.collectAsState()
    val rawRequests by viewModel.rawRequests.collectAsState()
    val rawContents by viewModel.rawContents.collectAsState()
    val rawAnnouncements by viewModel.rawAnnouncements.collectAsState()
    val plans by viewModel.plans.collectAsState()
    val admin by viewModel.currentAdmin.collectAsState()

    val pendingRequestsCount = rawRequests.count { it.status == RequestStatus.PENDING }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("admin_dashboard_screen_root")
    ) {
        // Hero Banner with Streamix Red Accent
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                StreamixRed.copy(alpha = 0.5f),
                                DarkSurfaceBorder,
                                DarkSurfaceBorder.copy(alpha = 0.4f)
                            )
                        ),
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    StreamixRed.copy(alpha = 0.16f),
                                    Color.Transparent
                                ),
                                radius = 400f
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(listOf(StreamixRed, StreamixRedDark))
                                        )
                                        .border(1.5.dp, StreamixRedLight.copy(alpha = 0.6f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = (admin?.username ?: "Admin").take(1).uppercase(),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Welcome, ${admin?.username ?: "Administrator"}",
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 0.2.sp,
                                        color = TextPrimary
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 2.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(SuccessEmerald)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Cluster: ${telemetry.serverStatus} • Uptime ${"%.1f".format(telemetry.serverUptimePercent)}%",
                                            fontSize = 11.sp,
                                            color = TextSecondary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }

                            IconButton(
                                onClick = { viewModel.refreshTelemetry() },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(DarkSurfaceElevated)
                                    .border(1.dp, DarkSurfaceBorder, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh Telemetry",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Quick OTT System Metric Strip
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurfaceElevated)
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text("Active Streams", fontSize = 10.sp, color = TextTertiary)
                                Text("%,d".format(telemetry.activeStreamers), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Column {
                                Text("Bandwidth", fontSize = 10.sp, color = TextTertiary)
                                Text("${"%.1f".format(telemetry.bandwidthUsageTb)} TB", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = StreamixRedLight)
                            }
                            Column {
                                Text("Edge Latency", fontSize = 10.sp, color = TextTertiary)
                                Text("${telemetry.apiLatencyMs}ms", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyanAccent)
                            }
                            Column {
                                Text("CDN Hit Rate", fontSize = 10.sp, color = TextTertiary)
                                Text("${"%.1f".format(telemetry.cdnCacheHitRatePercent)}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SuccessEmerald)
                            }
                        }
                    }
                }
            }
        }

        // Section: Primary OTT Metrics Grid
        item {
            SectionHeader(
                title = "Live Overview",
                subtitle = "Real-time metrics across Streamix cluster"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AdminStatCard(
                        title = "TOTAL USERS",
                        value = "%,d".format(rawUsers.size),
                        subtitle = "${rawUsers.count { it.status == com.example.model.UserStatus.ACTIVE }} active accounts",
                        icon = Icons.Default.People,
                        accentColor = StreamixRed,
                        onClick = { onNavigateToScreen(AdminScreen.USERS) },
                        modifier = Modifier.weight(1f).testTag("stat_card_users")
                    )
                    AdminStatCard(
                        title = "USER REQUESTS",
                        value = "${rawRequests.size}",
                        subtitle = "$pendingRequestsCount require attention",
                        icon = Icons.Default.ConfirmationNumber,
                        accentColor = if (pendingRequestsCount > 0) WarningAmber else InfoSky,
                        onClick = { onNavigateToScreen(AdminScreen.REQUESTS) },
                        modifier = Modifier.weight(1f).testTag("stat_card_requests")
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AdminStatCard(
                        title = "MEDIA CATALOG",
                        value = "${rawContents.size}",
                        subtitle = "${rawContents.count { it.isFeatured }} featured titles",
                        icon = Icons.Default.Movie,
                        accentColor = CyanAccent,
                        onClick = { onNavigateToScreen(AdminScreen.CONTENT) },
                        modifier = Modifier.weight(1f).testTag("stat_card_content")
                    )
                    AdminStatCard(
                        title = "EST. MRR",
                        value = "$%,.0f".format(telemetry.monthlyRecurringRevenue),
                        subtitle = "${plans.sumOf { it.activeSubscribers }} premium subs",
                        icon = Icons.Default.MonetizationOn,
                        accentColor = SuccessEmerald,
                        onClick = { onNavigateToScreen(AdminScreen.PREMIUM) },
                        modifier = Modifier.weight(1f).testTag("stat_card_revenue")
                    )
                }
            }
        }

        // Section: Management Modules Navigation
        item {
            SectionHeader(
                title = "Management Modules",
                subtitle = "Direct control panels for Streamix User App"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ManagementNavigationTile(
                    title = "User & Account Governance",
                    subtitle = "Manage subscriber statuses, device limits, tiers & moderation",
                    icon = Icons.Default.ManageAccounts,
                    accentColor = StreamixRed,
                    badgeText = "${rawUsers.size} Users",
                    onClick = { onNavigateToScreen(AdminScreen.USERS) }
                )

                ManagementNavigationTile(
                    title = "User Tickets & Content Requests",
                    subtitle = "Review, resolve and notify users on requested titles & reports",
                    icon = Icons.Default.MarkChatUnread,
                    accentColor = if (pendingRequestsCount > 0) WarningAmber else InfoSky,
                    badgeText = if (pendingRequestsCount > 0) "$pendingRequestsCount Pending" else "All Clear",
                    onClick = { onNavigateToScreen(AdminScreen.REQUESTS) }
                )

                ManagementNavigationTile(
                    title = "Media Catalog & Transcoding",
                    subtitle = "Publish HLS/DASH streams, edit 4K resolutions & featured banners",
                    icon = Icons.Default.VideoLibrary,
                    accentColor = CyanAccent,
                    badgeText = "${rawContents.size} Titles",
                    onClick = { onNavigateToScreen(AdminScreen.CONTENT) }
                )

                ManagementNavigationTile(
                    title = "Broadcast Alerts & Notifications",
                    subtitle = "Push global announcements, update logs and maintenance notices",
                    icon = Icons.Default.Campaign,
                    accentColor = PurpleBadge,
                    badgeText = "${rawAnnouncements.size} Broadcasts",
                    onClick = { onNavigateToScreen(AdminScreen.ANNOUNCEMENTS) }
                )

                ManagementNavigationTile(
                    title = "Subscription Tiers & Promo Codes",
                    subtitle = "Configure Ultra 4K, Family plans, billing pricing & coupons",
                    icon = Icons.Default.Stars,
                    accentColor = SuccessEmerald,
                    badgeText = "${plans.size} Plans",
                    onClick = { onNavigateToScreen(AdminScreen.PREMIUM) }
                )
            }
        }

        // Section: Cluster Telemetry & Transcoder Load
        item {
            SectionHeader(
                title = "Cluster Infrastructure",
                subtitle = "Hardware load, transcoder jobs & nodes"
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    TelemetryProgressBar("Transcoder Queue", "${telemetry.transcodingQueueJobs} Active Jobs", telemetry.transcodingQueueJobs / 10f, CyanAccent)
                    Spacer(modifier = Modifier.height(10.dp))
                    TelemetryProgressBar("CPU Cluster Load", "${telemetry.cpuUsagePercent}% Utilized", telemetry.cpuUsagePercent / 100f, StreamixRed)
                    Spacer(modifier = Modifier.height(10.dp))
                    TelemetryProgressBar("Edge Memory (RAM)", "${telemetry.ramUsagePercent}% Allocated", telemetry.ramUsagePercent / 100f, InfoSky)
                }
            }
        }
    }
}

@Composable
private fun ManagementNavigationTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    badgeText: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSurfaceElevated,
                modifier = Modifier.border(1.dp, DarkSurfaceBorder, RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = badgeText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun TelemetryProgressBar(
    label: String,
    valueLabel: String,
    fraction: Float,
    color: Color
) {
    Column {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(label, fontSize = 11.sp, color = TextSecondary)
            Text(valueLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction.coerceIn(0f, 1f) },
            color = color,
            trackColor = DarkSurfaceElevated,
            drawStopIndicator = {},
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}
