package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AuditLogEntry
import com.example.ui.AdminViewModel
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: AdminViewModel,
    onLogoutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val admin by viewModel.currentAdmin.collectAsState()
    val serverEndpoint by viewModel.serverEndpoint.collectAsState()
    val isTwoFactorRequired by viewModel.isTwoFactorRequired.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    var endpointInput by remember(serverEndpoint) { mutableStateOf(serverEndpoint) }
    var pingStatus by remember { mutableStateOf<String?>(null) }
    var isPinging by remember { mutableStateOf(false) }
    var showAuditLogsDialog by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("settings_screen_root")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Admin Profile Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            Brush.linearGradient(
                                listOf(
                                    StreamixRed.copy(alpha = 0.4f),
                                    DarkSurfaceBorder,
                                    DarkSurfaceBorder.copy(alpha = 0.5f)
                                )
                            ),
                            RoundedCornerShape(18.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(StreamixRed, StreamixRedDark)
                                        )
                                    )
                                    .border(2.dp, StreamixRedLight.copy(alpha = 0.7f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = admin?.username ?: "Master Administrator",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.2.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = admin?.email ?: "admin@streamix.io",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = StreamixRed.copy(alpha = 0.2f),
                                    modifier = Modifier
                                        .padding(top = 4.dp)
                                        .border(1.dp, StreamixRed.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                ) {
                                    Text(
                                        text = admin?.role?.displayName ?: "Super Admin",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StreamixRedLight,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Session Token", fontSize = 11.sp, color = TextTertiary)
                            Text(admin?.sessionToken?.take(16)?.let { "$it..." } ?: "None", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = CyanAccent)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Last Authenticated", fontSize = 11.sp, color = TextTertiary)
                            Text(admin?.lastLoginFormatted ?: "Today", fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }
            }

            // Backend & Database Integration
            item {
                SectionHeader(
                    title = "Backend & Gateway Endpoint",
                    subtitle = "Connection target for shared Streamix cluster"
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        OutlinedTextField(
                            value = endpointInput,
                            onValueChange = { endpointInput = it },
                            label = { Text("Streamix Shared API Gateway URL") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StreamixRed,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = DarkSurfaceElevated,
                                unfocusedContainerColor = DarkSurfaceElevated
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    viewModel.updateServerEndpoint(endpointInput)
                                    snackbarMessage = "Target endpoint updated to $endpointInput"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StreamixRed),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Save Endpoint", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    isPinging = true
                                    pingStatus = "Testing gateway latency..."
                                    val latency = (16..32).random()
                                    pingStatus = "200 OK • Response in ${latency}ms (TLS 1.3 Active)"
                                    isPinging = false
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Test Ping", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (pingStatus != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SuccessEmerald.copy(alpha = 0.15f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, SuccessEmerald.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = pingStatus ?: "",
                                    fontSize = 11.sp,
                                    color = SuccessEmerald,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Security Controls
            item {
                SectionHeader(
                    title = "Security & Governance",
                    subtitle = "Two-factor authentication, audit logs & telemetry"
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // 2FA Switch
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Enforce 2FA for Admin Sign-In", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Requires 6-digit TOTP token upon authentication", fontSize = 11.sp, color = TextSecondary)
                            }
                            Switch(
                                checked = isTwoFactorRequired,
                                onCheckedChange = {
                                    viewModel.toggleTwoFactorRequired(it)
                                    snackbarMessage = if (it) "2FA authentication enforced" else "2FA enforcement disabled"
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = StreamixRed,
                                    checkedTrackColor = StreamixRed.copy(alpha = 0.3f)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Audit log inspection
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("System Audit & Security Trail", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("${auditLogs.size} recent administrative operations recorded", fontSize = 11.sp, color = TextSecondary)
                            }
                            OutlinedButton(
                                onClick = { showAuditLogsDialog = true },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("View Logs", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // About & Compatibility Footnote
            item {
                SectionHeader(
                    title = "System Architecture",
                    subtitle = "Streamix ecosystem version alignment"
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Admin Console Version", fontSize = 12.sp, color = TextSecondary)
                            Text("v2.0.0-PREMIUM", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Target Streamix User App API", fontSize = 12.sp, color = TextSecondary)
                            Text("v2.4.0 (Compatible)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SuccessEmerald)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Environment Isolation", fontSize = 12.sp, color = TextSecondary)
                            Text("Dedicated Admin App Container", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = StreamixRedLight)
                        }
                    }
                }
            }

            // Sign Out Button
            item {
                Button(
                    onClick = onLogoutClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StreamixRed.copy(alpha = 0.15f), contentColor = StreamixRedLight),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .border(1.dp, StreamixRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .testTag("admin_signout_button")
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Terminate Admin Session & Logout", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Full Audit Logs Dialog
        if (showAuditLogsDialog) {
            AlertDialog(
                onDismissRequest = { showAuditLogsDialog = false },
                containerColor = DarkSurface,
                titleContentColor = TextPrimary,
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(StreamixRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Streamix Admin Audit Trail", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 360.dp)
                    ) {
                        items(auditLogs, key = { it.id }) { log ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, DarkSurfaceBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(log.action, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StreamixRedLight)
                                        Text(log.timestamp, fontSize = 10.sp, color = TextTertiary)
                                    }
                                    Text("Target: ${log.target}", fontSize = 11.sp, color = TextPrimary, modifier = Modifier.padding(top = 2.dp))
                                    Text("Admin: ${log.adminName} (${log.ipAddress})", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.padding(top = 2.dp))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAuditLogsDialog = false }) { Text("Close", color = StreamixRedLight, fontWeight = FontWeight.Bold) }
                }
            )
        }

        // Snackbar
        snackbarMessage?.let { msg ->
            Snackbar(
                action = { TextButton(onClick = { snackbarMessage = null }) { Text("OK", color = StreamixRedLight, fontWeight = FontWeight.Bold) } },
                containerColor = DarkSurfaceElevated,
                contentColor = TextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Text(msg)
            }
        }
    }
}
