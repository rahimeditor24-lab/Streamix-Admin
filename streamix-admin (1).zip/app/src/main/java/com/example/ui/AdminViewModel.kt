package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AdminAuthRepository
import com.example.data.AdminRepository
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AdminViewModel(
    private val authRepository: AdminAuthRepository = AdminAuthRepository(),
    private val adminRepository: AdminRepository = AdminRepository()
) : ViewModel() {

    val currentAdmin: StateFlow<AdminUser?> = authRepository.currentAdmin
    val serverEndpoint: StateFlow<String> = authRepository.serverEndpoint
    val isTwoFactorRequired: StateFlow<Boolean> = authRepository.isTwoFactorRequired
    val loginError: StateFlow<String?> = authRepository.loginError

    val telemetry: StateFlow<SystemTelemetry> = adminRepository.telemetry
    val rawUsers: StateFlow<List<StreamixUser>> = adminRepository.users
    val rawRequests: StateFlow<List<UserRequest>> = adminRepository.requests
    val rawContents: StateFlow<List<MediaContent>> = adminRepository.contents
    val rawAnnouncements: StateFlow<List<Announcement>> = adminRepository.announcements
    val plans: StateFlow<List<PremiumPlan>> = adminRepository.plans
    val promoCodes: StateFlow<List<PromoCode>> = adminRepository.promoCodes
    val auditLogs: StateFlow<List<AuditLogEntry>> = adminRepository.auditLogs

    // --- Search & Filter States ---
    private val _userSearchQuery = MutableStateFlow("")
    val userSearchQuery: StateFlow<String> = _userSearchQuery.asStateFlow()

    private val _userStatusFilter = MutableStateFlow<UserStatus?>(null)
    val userStatusFilter: StateFlow<UserStatus?> = _userStatusFilter.asStateFlow()

    private val _requestStatusFilter = MutableStateFlow<RequestStatus?>(null)
    val requestStatusFilter: StateFlow<RequestStatus?> = _requestStatusFilter.asStateFlow()

    private val _requestTypeFilter = MutableStateFlow<RequestType?>(null)
    val requestTypeFilter: StateFlow<RequestType?> = _requestTypeFilter.asStateFlow()

    private val _contentTypeFilter = MutableStateFlow<ContentType?>(null)
    val contentTypeFilter: StateFlow<ContentType?> = _contentTypeFilter.asStateFlow()

    private val _announcementStatusFilter = MutableStateFlow<AnnouncementStatus?>(null)
    val announcementStatusFilter: StateFlow<AnnouncementStatus?> = _announcementStatusFilter.asStateFlow()

    // --- Filtered Flows ---
    val filteredUsers = combine(rawUsers, _userSearchQuery, _userStatusFilter) { list, query, status ->
        list.filter { user ->
            val matchesQuery = query.isBlank() ||
                    user.username.contains(query, ignoreCase = true) ||
                    user.email.contains(query, ignoreCase = true) ||
                    user.id.contains(query, ignoreCase = true)
            val matchesStatus = status == null || user.status == status
            matchesQuery && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredRequests = combine(rawRequests, _requestStatusFilter, _requestTypeFilter) { list, status, type ->
        list.filter { req ->
            val matchesStatus = status == null || req.status == status
            val matchesType = type == null || req.type == type
            matchesStatus && matchesType
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredContents = combine(rawContents, _contentTypeFilter) { list, type ->
        list.filter { content ->
            type == null || content.type == type
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredAnnouncements = combine(rawAnnouncements, _announcementStatusFilter) { list, status ->
        list.filter { ann ->
            status == null || ann.status == status
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // --- Auth Actions ---
    fun login(emailOrUsername: String, passkey: String, twoFactorPin: String?): Boolean {
        return authRepository.login(emailOrUsername, passkey, twoFactorPin)
    }

    fun clearLoginError() {
        authRepository.clearLoginError()
    }

    fun logout() {
        authRepository.logout()
    }

    fun updateServerEndpoint(endpoint: String) {
        authRepository.updateServerEndpoint(endpoint)
    }

    fun toggleTwoFactorRequired(required: Boolean) {
        authRepository.toggleTwoFactorRequired(required)
    }

    // --- User Actions ---
    fun setUserSearchQuery(query: String) {
        _userSearchQuery.value = query
    }

    fun setUserStatusFilter(status: UserStatus?) {
        _userStatusFilter.value = status
    }

    fun updateUserStatus(userId: String, newStatus: UserStatus, reason: String? = null) {
        adminRepository.updateUserStatus(userId, newStatus, reason)
    }

    fun updateUserTier(userId: String, newTier: SubscriptionTier) {
        adminRepository.updateUserTier(userId, newTier)
    }

    // --- Request Actions ---
    fun setRequestStatusFilter(status: RequestStatus?) {
        _requestStatusFilter.value = status
    }

    fun setRequestTypeFilter(type: RequestType?) {
        _requestTypeFilter.value = type
    }

    fun resolveRequest(requestId: String, status: RequestStatus, note: String?) {
        val adminName = currentAdmin.value?.username ?: "Admin"
        adminRepository.updateRequestStatus(requestId, status, note, adminName)
    }

    // --- Content Actions ---
    fun setContentTypeFilter(type: ContentType?) {
        _contentTypeFilter.value = type
    }

    fun addContent(
        title: String,
        type: ContentType,
        genre: String,
        resolution: String,
        releaseYear: Int,
        duration: String,
        streamUrl: String,
        isFeatured: Boolean
    ) {
        adminRepository.addContent(title, type, genre, resolution, releaseYear, duration, streamUrl, isFeatured)
    }

    fun toggleContentStatus(contentId: String) {
        adminRepository.toggleContentStatus(contentId)
    }

    fun toggleContentFeatured(contentId: String) {
        adminRepository.toggleContentFeatured(contentId)
    }

    fun deleteContent(contentId: String) {
        adminRepository.deleteContent(contentId)
    }

    // --- Announcement Actions ---
    fun setAnnouncementStatusFilter(status: AnnouncementStatus?) {
        _announcementStatusFilter.value = status
    }

    fun createAnnouncement(
        title: String,
        message: String,
        audience: TargetAudience,
        priority: AnnouncementPriority,
        expiresInDays: Int = 14,
        actionUrl: String? = null
    ) {
        adminRepository.createAnnouncement(title, message, audience, priority, expiresInDays, actionUrl)
    }

    fun toggleAnnouncementStatus(announcementId: String) {
        adminRepository.toggleAnnouncementStatus(announcementId)
    }

    fun deleteAnnouncement(announcementId: String) {
        adminRepository.deleteAnnouncement(announcementId)
    }

    // --- Premium & Promo Actions ---
    fun togglePlanStatus(planId: String) {
        adminRepository.togglePlanStatus(planId)
    }

    fun createPromoCode(code: String, discount: Int, planName: String, maxRedemptions: Int, expiry: String) {
        adminRepository.createPromoCode(code, discount, planName, maxRedemptions, expiry)
    }

    fun togglePromoActive(promoId: String) {
        adminRepository.togglePromoActive(promoId)
    }

    fun deletePromoCode(promoId: String) {
        adminRepository.deletePromoCode(promoId)
    }

    fun refreshTelemetry() {
        adminRepository.refreshTelemetry()
    }
}
