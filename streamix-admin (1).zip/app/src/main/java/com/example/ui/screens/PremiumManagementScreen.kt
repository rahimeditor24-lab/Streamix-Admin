package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PremiumPlan
import com.example.model.PromoCode
import com.example.ui.AdminViewModel
import com.example.ui.components.EmptyListCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun PremiumManagementScreen(
    viewModel: AdminViewModel,
    modifier: Modifier = Modifier
) {
    val plans by viewModel.plans.collectAsState()
    val promoCodes by viewModel.promoCodes.collectAsState()

    var showCreatePromoModal by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("premium_management_screen_root")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            item {
                SectionHeader(
                    title = "Subscription Plans & Tiers",
                    subtitle = "Configure billing tiers, screen allowances & resolution caps"
                )
            }

            // Plans List
            items(plans, key = { it.id }) { plan ->
                PlanCard(
                    plan = plan,
                    onToggleEnabled = {
                        viewModel.togglePlanStatus(plan.id)
                        snackbarMessage = "Updated status for ${plan.name}"
                    }
                )
            }

            // Promo Codes Header
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Promotional Vouchers",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.2.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Campaign coupons for customer onboarding",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { showCreatePromoModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StreamixRed),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("create_promo_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Promo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Promo Codes List
            if (promoCodes.isEmpty()) {
                item {
                    EmptyListCard("No Promo Codes", "Create discount vouchers for marketing campaigns.")
                }
            } else {
                items(promoCodes, key = { it.id }) { promo ->
                    PromoCodeCard(
                        promo = promo,
                        onToggleActive = {
                            viewModel.togglePromoActive(promo.id)
                            snackbarMessage = "Toggled status for ${promo.code}"
                        },
                        onDelete = {
                            viewModel.deletePromoCode(promo.id)
                            snackbarMessage = "Deleted promo ${promo.code}"
                        }
                    )
                }
            }
        }

        // Create Promo Modal
        if (showCreatePromoModal) {
            CreatePromoModal(
                onDismiss = { showCreatePromoModal = false },
                onConfirm = { code, discount, plan, max, expiry ->
                    viewModel.createPromoCode(code, discount, plan, max, expiry)
                    showCreatePromoModal = false
                    snackbarMessage = "Created promo code $code ($discount% off)"
                }
            )
        }

        // Toast
        snackbarMessage?.let { msg ->
            Snackbar(
                action = { TextButton(onClick = { snackbarMessage = null }) { Text("OK", color = StreamixRedLight, fontWeight = FontWeight.Bold) } },
                containerColor = DarkSurfaceElevated,
                contentColor = TextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Text(msg)
            }
        }
    }
}

@Composable
private fun PlanCard(
    plan: PremiumPlan,
    onToggleEnabled: () -> Unit
) {
    val isUltra = plan.name.contains("Ultra", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (plan.isPopular || isUltra) StreamixRed.copy(alpha = 0.5f) else DarkSurfaceBorder,
                RoundedCornerShape(16.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = plan.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (plan.isPopular) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = StreamixRed.copy(alpha = 0.2f),
                                modifier = Modifier.border(1.dp, StreamixRed.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            ) {
                                Text(
                                    text = "MOST POPULAR",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = StreamixRedLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = "$${plan.priceMonthly}/mo • $${plan.priceYearly}/yr",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isUltra) StreamixRedLight else CyanAccent,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Switch(
                    checked = plan.isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = StreamixRed,
                        checkedTrackColor = StreamixRed.copy(alpha = 0.3f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Specs grid
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurfaceElevated)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Max Screens", fontSize = 10.sp, color = TextTertiary)
                    Text("${plan.maxScreens} devices", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Column(modifier = Modifier.weight(1.2f)) {
                    Text("Resolution", fontSize = 10.sp, color = TextTertiary)
                    Text(plan.maxResolution, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Subscribers", fontSize = 10.sp, color = TextTertiary)
                    Text("%,d".format(plan.activeSubscribers), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = StreamixRedLight)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Feature bullets
            plan.features.forEach { feature ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessEmerald, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(feature, fontSize = 11.sp, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun PromoCodeCard(
    promo: PromoCode,
    onToggleActive: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(14.dp))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = promo.code,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = if (promo.isActive) StreamixRedLight else TextSecondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = StreamixRed.copy(alpha = 0.15f),
                        modifier = Modifier.border(1.dp, StreamixRed.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = "-${promo.discountPercent}% OFF",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = StreamixRedLight,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = "Applies to: ${promo.applicablePlan} • Expires: ${promo.expiresAt}",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Text(
                    text = "Redemptions: ${promo.redeemedCount} / ${promo.maxRedemptions}",
                    fontSize = 11.sp,
                    color = TextTertiary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = promo.isActive,
                    onCheckedChange = { onToggleActive() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = StreamixRed,
                        checkedTrackColor = StreamixRed.copy(alpha = 0.3f)
                    )
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRose)
                }
            }
        }
    }
}

@Composable
private fun CreatePromoModal(
    onDismiss: () -> Unit,
    onConfirm: (String, Int, String, Int, String) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("25") }
    var planName by remember { mutableStateOf("All Plans") }
    var maxRedemptions by remember { mutableStateOf("1000") }
    var expiry by remember { mutableStateOf("Sep 30, 2026") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        titleContentColor = TextPrimary,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(StreamixRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Promo Voucher", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.uppercase() },
                    label = { Text("Promo Code") },
                    placeholder = { Text("e.g., FALLSTREAM50") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = discount,
                        onValueChange = { discount = it },
                        label = { Text("Discount %") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StreamixRed,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = maxRedemptions,
                        onValueChange = { maxRedemptions = it },
                        label = { Text("Max Uses") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = StreamixRed,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = DarkSurfaceElevated,
                            unfocusedContainerColor = DarkSurfaceElevated
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = planName,
                    onValueChange = { planName = it },
                    label = { Text("Applicable Plan") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = expiry,
                    onValueChange = { expiry = it },
                    label = { Text("Expiry Date") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StreamixRed,
                        unfocusedBorderColor = DarkSurfaceBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (code.isNotBlank()) {
                        val parsedDisc = discount.toIntOrNull() ?: 20
                        val parsedMax = maxRedemptions.toIntOrNull() ?: 1000
                        onConfirm(code, parsedDisc, planName, parsedMax, expiry)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StreamixRed)
            ) {
                Text("Create Code", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
        }
    )
}
