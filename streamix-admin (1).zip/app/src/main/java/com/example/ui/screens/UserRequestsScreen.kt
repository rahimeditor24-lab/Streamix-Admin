package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.AdminViewModel
import com.example.ui.components.EmptyListCard
import com.example.ui.components.RequestPriorityBadge
import com.example.ui.components.RequestStatusBadge
import com.example.ui.theme.*

@Composable
fun UserRequestsScreen(
    viewModel: AdminViewModel,
    modifier: Modifier = Modifier
) {
    val requests by viewModel.filteredRequests.collectAsState()
    val rawRequests by viewModel.rawRequests.collectAsState()
    val currentStatusFilter by viewModel.requestStatusFilter.collectAsState()
    val currentTypeFilter by viewModel.requestTypeFilter.collectAsState()

    var activeRequestForAction by remember { mutableStateOf<UserRequest?>(null) }
    var actionTypeToPerform by remember { mutableStateOf<RequestStatus?>(null) }
    var adminResponseNote by remember { mutableStateOf("") }
    var showSnackbarMessage by remember { mutableStateOf<String?>(null) }

    val pendingCount = rawRequests.count { it.status == RequestStatus.PENDING }
    val inReviewCount = rawRequests.count { it.status == RequestStatus.IN_REVIEW }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("user_requests_screen_root")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Status Summary Row
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RequestStatSummaryChip("Pending", pendingCount, WarningAmber, Modifier.weight(1f))
                    RequestStatSummaryChip("In Review", inReviewCount, InfoSky, Modifier.weight(1f))
                    RequestStatSummaryChip("Total", rawRequests.size, StreamixRedLight, Modifier.weight(1f))
                }
            }

            // Status Filter Tabs
            item {
                Text("Filter by Status", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = currentStatusFilter == null,
                            onClick = { viewModel.setRequestStatusFilter(null) },
                            label = { Text("All (${rawRequests.size})", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = currentStatusFilter == null,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                    items(RequestStatus.entries) { status ->
                        val isSelected = currentStatusFilter == status
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setRequestStatusFilter(status) },
                            label = { Text(status.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRed
                            )
                        )
                    }
                }
            }

            // Type Filter Tabs
            item {
                Text("Filter by Category", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = currentTypeFilter == null,
                            onClick = { viewModel.setRequestTypeFilter(null) },
                            label = { Text("All Categories", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DarkSurfaceElevated,
                                selectedLabelColor = TextPrimary,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = currentTypeFilter == null,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = TextSecondary
                            )
                        )
                    }
                    items(RequestType.entries) { type ->
                        val isSelected = currentTypeFilter == type
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setRequestTypeFilter(type) },
                            label = { Text(type.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StreamixRed.copy(alpha = 0.2f),
                                selectedLabelColor = StreamixRedLight,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = StreamixRedLight
                            )
                        )
                    }
                }
            }

            // Request List
            if (requests.isEmpty()) {
                item {
                    EmptyListCard(
                        title = "No Requests Found",
                        subtitle = "No tickets match your active status/category filters."
                    )
                }
            } else {
                items(requests, key = { it.id }) { req ->
                    RequestItemCard(
                        request = req,
                        onApprove = {
                            activeRequestForAction = req
                            actionTypeToPerform = RequestStatus.APPROVED
                            adminResponseNote = "Your request has been approved and scheduled for release."
                        },
                        onReject = {
                            activeRequestForAction = req
                            actionTypeToPerform = RequestStatus.REJECTED
                            adminResponseNote = ""
                        },
                        onSetInReview = {
                            viewModel.resolveRequest(req.id, RequestStatus.IN_REVIEW, "Assigned to staff investigation.")
                            showSnackbarMessage = "Marked as In Review"
                        }
                    )
                }
            }
        }

        // Action Decision Dialog (Approve / Reject)
        if (activeRequestForAction != null && actionTypeToPerform != null) {
            val req = activeRequestForAction!!
            val action = actionTypeToPerform!!
            val isApprove = action == RequestStatus.APPROVED

            AlertDialog(
                onDismissRequest = {
                    activeRequestForAction = null
                    actionTypeToPerform = null
                },
                containerColor = DarkSurface,
                titleContentColor = if (isApprove) SuccessEmerald else DangerRose,
                title = {
                    Text(if (isApprove) "Approve Request: ${req.id}" else "Reject Request: ${req.id}")
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Title: ${req.title}\nSubmitted by: ${req.userName} (${req.userEmail})",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        Text(
                            text = if (isApprove) "Resolution notes for user:" else "Specify rejection reason (sent to user):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        OutlinedTextField(
                            value = adminResponseNote,
                            onValueChange = { adminResponseNote = it },
                            placeholder = {
                                Text(
                                    if (isApprove) "e.g., Added to transcoding schedule for 4K release."
                                    else "e.g., Does not comply with regional licensing."
                                )
                            },
                            singleLine = false,
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = if (isApprove) SuccessEmerald else DangerRose,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = DarkSurfaceElevated,
                                unfocusedContainerColor = DarkSurfaceElevated
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.resolveRequest(
                                req.id,
                                action,
                                adminResponseNote.ifEmpty { if (isApprove) "Approved by Admin" else "Rejected by Admin" }
                            )
                            showSnackbarMessage = "Ticket ${req.id} resolved as ${action.label}"
                            activeRequestForAction = null
                            actionTypeToPerform = null
                            adminResponseNote = ""
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isApprove) SuccessEmerald else DangerRose
                        )
                    ) {
                        Text(if (isApprove) "Confirm Approval" else "Confirm Rejection", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        activeRequestForAction = null
                        actionTypeToPerform = null
                    }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }

        // Feedback Snackbar
        showSnackbarMessage?.let { msg ->
            Snackbar(
                action = {
                    TextButton(onClick = { showSnackbarMessage = null }) {
                        Text("OK", color = StreamixRedLight, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = DarkSurfaceElevated,
                contentColor = TextPrimary,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Text(msg)
            }
        }
    }
}

@Composable
private fun RequestStatSummaryChip(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = modifier.border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$count",
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                color = color
            )
            Text(
                text = label,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun RequestItemCard(
    request: UserRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onSetInReview: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Type & Priority, Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = DarkSurfaceElevated,
                        modifier = Modifier.border(1.dp, DarkSurfaceBorder, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = request.type.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                    RequestPriorityBadge(priority = request.priority)
                }

                RequestStatusBadge(status = request.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = request.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = request.description,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Submitter & Timestamp Info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "By ${request.userName} • ${request.submittedAt}",
                    fontSize = 11.sp,
                    color = TextTertiary
                )
                Text(
                    text = request.id,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiary
                )
            }

            // Admin response history if resolved
            if (request.adminResponse != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurfaceElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Admin Note (${request.resolvedBy ?: "Staff"}):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StreamixRedLight
                        )
                        Text(
                            text = request.adminResponse,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            // Action Buttons for Pending / In Review
            if (request.status == RequestStatus.PENDING || request.status == RequestStatus.IN_REVIEW) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRose),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (request.status == RequestStatus.PENDING) {
                        IconButton(
                            onClick = onSetInReview,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurfaceElevated)
                                .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.HourglassTop, contentDescription = "Mark in review", tint = InfoSky)
                        }
                    }
                }
            }
        }
    }
}
