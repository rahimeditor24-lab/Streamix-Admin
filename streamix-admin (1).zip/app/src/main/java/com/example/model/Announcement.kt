package com.example.model

enum class TargetAudience(val label: String) {
    ALL_USERS("All Streamix Users"),
    PREMIUM_ONLY("Premium Subscribers"),
    FREE_TIER("Free Tier Users"),
    BETA_TESTERS("Beta Testers")
}

enum class AnnouncementPriority(val label: String) {
    INFO("Info"),
    UPDATE("System Update"),
    PROMO("Promotion"),
    URGENT("Urgent Alert")
}

enum class AnnouncementStatus(val label: String) {
    ACTIVE("Active / Live"),
    SCHEDULED("Scheduled"),
    EXPIRED("Expired"),
    DRAFT("Draft")
}

data class Announcement(
    val id: String,
    val title: String,
    val message: String,
    val audience: TargetAudience,
    val priority: AnnouncementPriority,
    val status: AnnouncementStatus,
    val createdAt: String,
    val expiresAt: String,
    val actionUrl: String? = null,
    val readCount: Int = 0
)
