package com.example.model

enum class UserStatus(val label: String) {
    ACTIVE("Active"),
    SUSPENDED("Suspended"),
    BANNED("Banned"),
    PENDING_VERIFICATION("Pending")
}

enum class SubscriptionTier(val label: String) {
    FREE("Free"),
    PLUS("Streamix Plus"),
    FAMILY("Streamix Family"),
    ULTRA_4K("Streamix Ultra 4K")
}

data class StreamixUser(
    val id: String,
    val username: String,
    val email: String,
    val tier: SubscriptionTier,
    val status: UserStatus,
    val joinedDate: String,
    val streamHours: Double,
    val ipCountry: String,
    val devicesCount: Int,
    val avatarInitials: String,
    val banReason: String? = null
)
