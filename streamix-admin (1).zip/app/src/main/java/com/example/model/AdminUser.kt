package com.example.model

enum class AdminRole(val displayName: String) {
    SUPER_ADMIN("Super Admin"),
    CONTENT_MANAGER("Content Manager"),
    MODERATOR("User Moderator"),
    BILLING_ADMIN("Billing Admin")
}

data class AdminUser(
    val id: String,
    val username: String,
    val email: String,
    val role: AdminRole,
    val serverEndpoint: String,
    val sessionToken: String,
    val lastLoginFormatted: String,
    val permissions: List<String> = listOf("ALL_PRIVILEGES")
)
