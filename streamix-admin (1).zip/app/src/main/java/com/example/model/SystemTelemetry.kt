package com.example.model

data class SystemTelemetry(
    val activeStreamers: Int,
    val totalUsers: Int,
    val pendingRequests: Int,
    val activeAnnouncements: Int,
    val monthlyRecurringRevenue: Double,
    val serverUptimePercent: Double,
    val bandwidthUsageTb: Double,
    val transcodingQueueJobs: Int,
    val apiLatencyMs: Int,
    val cpuUsagePercent: Int,
    val ramUsagePercent: Int,
    val cdnCacheHitRatePercent: Double,
    val serverStatus: String = "OPERATIONAL"
)

data class AuditLogEntry(
    val id: String,
    val timestamp: String,
    val adminName: String,
    val action: String,
    val target: String,
    val ipAddress: String
)
