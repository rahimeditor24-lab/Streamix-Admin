package com.example.model

enum class RequestType(val label: String) {
    CONTENT_REQUEST("Content Request"),
    ACCOUNT_ISSUE("Account Issue"),
    BILLING_SUPPORT("Billing / Refund"),
    FEATURE_SUGGESTION("Feature Request"),
    STREAM_QUALITY("Stream Quality Issue")
}

enum class RequestPriority(val label: String) {
    LOW("Low"),
    NORMAL("Normal"),
    HIGH("High"),
    URGENT("Urgent")
}

enum class RequestStatus(val label: String) {
    PENDING("Pending"),
    IN_REVIEW("In Review"),
    APPROVED("Approved"),
    REJECTED("Rejected")
}

data class UserRequest(
    val id: String,
    val userId: String,
    val userName: String,
    val userEmail: String,
    val type: RequestType,
    val priority: RequestPriority,
    val status: RequestStatus,
    val title: String,
    val description: String,
    val submittedAt: String,
    val adminResponse: String? = null,
    val resolvedBy: String? = null
)
