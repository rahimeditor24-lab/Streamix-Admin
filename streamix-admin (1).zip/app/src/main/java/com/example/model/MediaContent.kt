package com.example.model

enum class ContentType(val label: String) {
    MOVIE("Movie"),
    TV_SERIES("TV Series"),
    LIVE_STREAM("Live Stream"),
    ANIME("Anime"),
    DOCUMENTARY("Documentary")
}

enum class ContentStatus(val label: String) {
    PUBLISHED("Published"),
    DRAFT("Draft"),
    SCHEDULED("Scheduled"),
    FLAGGED("Flagged")
}

data class MediaContent(
    val id: String,
    val title: String,
    val type: ContentType,
    val genre: String,
    val resolution: String, // "4K HDR", "1080p FHD", "720p HD"
    val releaseYear: Int,
    val durationOrEpisodes: String,
    val viewsCount: Long,
    val rating: Double,
    val status: ContentStatus,
    val isFeatured: Boolean,
    val streamUrl: String,
    val addedDate: String
)
