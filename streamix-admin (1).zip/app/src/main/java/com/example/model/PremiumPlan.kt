package com.example.model

data class PremiumPlan(
    val id: String,
    val name: String,
    val priceMonthly: Double,
    val priceYearly: Double,
    val maxScreens: Int,
    val maxResolution: String,
    val audioQuality: String,
    val activeSubscribers: Int,
    val features: List<String>,
    val isPopular: Boolean = false,
    val isEnabled: Boolean = true
)

data class PromoCode(
    val id: String,
    val code: String,
    val discountPercent: Int,
    val applicablePlan: String,
    val maxRedemptions: Int,
    val redeemedCount: Int,
    val expiresAt: String,
    val isActive: Boolean
)
